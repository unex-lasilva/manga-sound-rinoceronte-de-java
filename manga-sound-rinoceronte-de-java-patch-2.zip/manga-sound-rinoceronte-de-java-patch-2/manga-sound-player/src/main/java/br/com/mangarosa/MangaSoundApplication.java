package br.com.mangarosa;

public class MangaSoundApplication
{
    public static void main( String[] args ) {

        System.out.println( "Welcome to Manga Sound Player" );
    }
}
